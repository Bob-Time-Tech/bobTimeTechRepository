rootProject.name = "LinuxCommandGame"

